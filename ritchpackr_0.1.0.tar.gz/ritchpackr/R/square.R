#' Square a number
#'
#' Takes in any numeric value and squares it
#' @param x a numeric value to be squared
#' @return the square of the input
#'
#'
#' @export
square <- function (x){
  return(x^2)
}
